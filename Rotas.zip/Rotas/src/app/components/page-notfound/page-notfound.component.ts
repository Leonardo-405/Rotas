import { Component } from '@angular/core';

@Component({
  selector: 'app-page-notfound',
  templateUrl: './page-notfound.component.html',
  styleUrl: './page-notfound.component.css'
})
export class PageNotfoundComponent {

}
